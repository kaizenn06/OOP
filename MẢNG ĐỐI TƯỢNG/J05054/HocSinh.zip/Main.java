package J05054;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        HocSinh[] hs = new HocSinh[n];
        for (int i = 0 ; i < n ; i++) {
            hs[i] = new HocSinh(i + 1, sc.nextLine(), Double.parseDouble(sc.nextLine()));
        }
        Arrays.sort(hs);
        for (int i = 0 ; i < n ; i++) {
            if (i > 0 && hs[i].getAvg() == hs[i - 1].getAvg()) {
                hs[i].setRank(hs[i - 1].getRank());
            }
            else hs[i].setRank(i + 1);
        }
        for (int i = n - 1 ; i >= 0 ; i--) {
            System.out.println(hs[i]);
        }
    }
}
