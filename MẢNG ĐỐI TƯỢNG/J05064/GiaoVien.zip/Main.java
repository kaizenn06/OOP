package J05064;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        GiaoVien[] gv = new GiaoVien[n];
        for (int i = 0 ; i < n ; i++) {
            sc.nextLine();
            gv[i] = new GiaoVien(sc.nextLine(), sc.nextLine(), sc.nextInt());
        }
        int ht = 1, hp = 2;
        for (int i = 0 ; i < n ; i++) {
            if (gv[i].getId().substring(0, 2).equals("HT") && ht != 0) {
                ht--;
                System.out.println(gv[i]);
                continue;
            }
            else if (gv[i].getId().substring(0, 2).equals("HP") && hp != 0) {
                hp--;
                System.out.println(gv[i]);
                continue;
            }
            System.out.println(gv[i]);
        }
    }
}
