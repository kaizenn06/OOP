package J05048;

public class MaHang {
    private String id;
    private long quantity_in, quantity_out, price, money, tax;
    public MaHang(String id, long quantity) {
        this.id = id;
        this.quantity_in = quantity;
        this.quantity_out = out();
        this.price = dongia();
        this.money = this.quantity_out * this.price;
        this.tax = thue();
    }
    public long out() {
        Character key = id.charAt(0);
        if (key.equals('A')) return quantity_in * 60 / 100;
        else return quantity_in * 70 / 100;
    }
    public long dongia() {
        Character key = id.charAt(id.length() - 1);
        if (key.equals('Y')) return 110000;
        else return 135000;
    }
    public long thue() {
        Character key1 = id.charAt(0);
        Character key2 = id.charAt(id.length() - 1);
        if (key1.equals('A') && key2.equals('Y')) return money * 8 / 100;
        else if (key1.equals('A') && key2.equals('N')) return money * 11 / 100;
        else if (key1.equals('B') && key2.equals('Y')) return money * 17 / 100;
        else return money * 22 / 100;
    }
    @Override
    public String toString() {
        return String.format("%s %d %d %d %d %d", id, quantity_in, quantity_out, price, money, tax);
    }
}
